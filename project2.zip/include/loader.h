#ifndef _LOADER
#define _LOADER

#include <mips-memory.h>

void load_memory(memory_t * mem, char *filename);

#endif