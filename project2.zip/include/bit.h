#ifndef _BIT
#define _BIT

char word2btye(unsigned int word, int start, int end);

#endif