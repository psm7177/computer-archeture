#ifndef _DEBUG
#define _DEBUG

#include <stdio.h>
#include <stdarg.h>

void dbprintf(const char *format, ...);

#endif